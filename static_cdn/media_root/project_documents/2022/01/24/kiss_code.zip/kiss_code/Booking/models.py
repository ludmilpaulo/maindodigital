from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.dispatch import receiver
import datetime
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render,redirect
from django.core.mail import send_mail , BadHeaderError
from django.http import HttpResponse  , HttpResponseRedirect

# Create your models here.



   

class Reservation(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    phone = models.CharField(max_length=9)
    content = models.TextField(verbose_name='Conteúdo')
    image  = models.ImageField(upload_to='booking/', null=True, blank=True)
  
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp'] # most recent saved show up first
        verbose_name = 'Book'
        verbose_name_plural = 'Books'


    def __str__(self):
        return self.name

def save(self, *args, **kwargs):
    created = self.pk is None
    return super().save(*args, **kwargs)
    if created:
        send_mail(name,email,phone,content['contacto@vemlimpar.com'])

 


# @receiver(post_save, sender=User)
# def first_mail(sender, instance, **kwargs):
#     if kwargs['created']:
#         user_email = instance.name.email
#         subject, from_email, to = 'New Post', 'contacto@vemlimpar.com', user_email

#         text_content = render_to_string('post/mail_post.txt')
#         html_content = render_to_string('post/mail_post.html')

#         # create the email, and attach the HTML version as well.
#         msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
#         msg.attach_alternative(html_content, "text/html")
#         msg.send()