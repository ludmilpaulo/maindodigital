from django.db import models

# Create your models here.

class AboutUs(models.Model):
    title = models.CharField(max_length = 50)
    content = models.TextField()
    image = models.ImageField(upload_to='about_us/', verbose_name='Backgroup Image')
    # image1 = models.ImageField(upload_to='about_us/', verbose_name='First Image')
    # image2 = models.ImageField(upload_to='about_us/', verbose_name='second Image')
    video = models.URLField(verbose_name='Video Link')

    class Meta:
        verbose_name = 'about us '
        verbose_name_plural = 'about us '

    def __str__(self):
        return self.title


class Why_Choose_Us(models.Model):
    title = models.CharField(max_length=50)
    content = models.TextField()

    class Meta:
        verbose_name = 'why choose us '
        verbose_name_plural = 'why choose us '

    def __str__(self):
        return self.title


class Chef(models.Model):
    name = models.CharField(max_length=50)
    title = models.CharField(max_length=50)
    facebook = models.URLField(verbose_name='facebook Link')
    linkedin = models.URLField(verbose_name='linkedin Link')
    skype = models.URLField(verbose_name='skype Link')
    instagram = models.URLField(verbose_name='instagram Link')

    image = models.ImageField(upload_to='chef/')    

    class Meta:
        verbose_name = 'Squad'
        verbose_name_plural = 'Squad'

    def __str__(self):
        return self.name