from django.shortcuts import render, redirect
from .models import Reservation
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render,redirect
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from .forms import ReserveTableForm
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render,redirect
from django.core.mail import send_mail , BadHeaderError
from django.http import HttpResponse  , HttpResponseRedirect

from .models import Reservation

def reserve_table(request):
     form_class = ReserveTableForm()
     bg = Reservation.objects.all()
    

     if request.method == 'POST':
        form_class = ReserveTableForm(request.POST)

        if form_class.is_valid():
            form_class.save()

            return redirect('home')
    	
    # if request.method == 'POST':
    #     form_class = ReserveTableForm(request.POST)
    #     if form_class.is_valid():
    #         name = form_class.cleaned_data['name']
    #         email = form_class.cleaned_data['email']
    #         content = form_class.cleaned_data['content']

    #         try : 
    #             send_mail(name,content,email,['contacto@vemlimpar.com'])

    #         except BadHeaderError:
    #             return HttpResponse('ivalid header') 

    #         return redirect('home')
    


     context = {
    	'form' : form_class,
    	'bg' : bg
     }

     return render(request , 'reservation.html' , context)

