from .models import *


def slider_movies(request):
    movies = Video.objects.all().order_by('created')[0:3]
    # movies = Movie.objects.last()
    return {'slider_movie' : movies}