from django.db import models
from django.utils.text import slugify
from django.utils import timezone
from django.conf import settings
from django.db.models.signals import post_save, pre_save
from django.urls import reverse
# Create your models here.

CATEGORY_CHOICES = (
    ('music','MUSIC'),
    ('shoot','SHOOT'),
    ('wedding','WEDDING'),
    ('event','EVENT'),
)



STATUS_CHOICES = (
    ('RA' , 'RECRNTLY ADDED'),
)

class Video(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(max_length=1000)
    image = models.ImageField(upload_to='Videos')
    banner = models.ImageField(upload_to='Videos_banner')
    category = models.ForeignKey('Category'  ,null=True, on_delete=models.SET_NULL)
    status = models.CharField(choices=STATUS_CHOICES , max_length=2)
    cast = models.CharField(max_length=100)
    year_of_production = models.DateField()
    views_count = models.IntegerField(default=0)
    movie_trailer = models.URLField(verbose_name='Video Link')
 

    created = models.DateTimeField(default=timezone.now)

    slug = models.SlugField(blank=True, null=True)

    def save(self , *args , **kwargs):
        if not self.slug :
            self.slug = slugify(self.title)
        super(Video , self).save( *args , **kwargs)

    def __str__(self):
        return self.title

    class Meta:
       verbose_name ='Video'
       verbose_name_plural ='Videos'

class Category(models.Model):
    category_name = models.CharField(max_length=50)


    def __str__(self):
        return self.category_name


 
