from django.shortcuts import render

# Create your views here.
from django.views.generic import ListView , DetailView
from django.views.generic.dates import YearArchiveView
from .models import *





class HomeView(ListView):
    model = Video
    template_name = 'Video/home.html'

    def get_context_data(self , **kwargs):
        context = super(HomeView , self).get_context_data(**kwargs)
        context['top_rated'] = Video.objects.filter(status='TR')
        context['most_watched'] = Video.objects.filter(status='MW')
        context['recently_added'] = Video.objects.filter(status='RA') 
        return context


class MovieList(ListView):
    model = Video
    paginate_by = 2


class MovieDetail(DetailView):
    model = Video

    def get_object(self):
        object = super(MovieDetail , self).get_object()
        object.views_count += 1
        object.save()
        return object

    def get_context_data(self , **kwargs):
        context = super(MovieDetail , self).get_context_data(**kwargs)
        #context['links'] = MovieLinks.objects.filter(movie=self.get_object())
        context['related_movies'] = Video.objects.filter(category=self.get_object().category)#.order_by['created'][0:6]
        return context


class MovieCategory(ListView):
    model = Video
    paginate_by = 2

    def get_queryset(self):
        self.category = self.kwargs['category']
        return Video.objects.filter(category=self.category)

    def get_context_data(self , **kwargs):
        context = super(MovieCategory , self).get_context_data(**kwargs)
        context['video_category'] = self.category
        return context




class MovieSearch(ListView):
    model = Video
    paginate_by = 2

    def get_queryset(self):
        query = self.request.GET.get('query')
        if query:
            object_list = self.model.objects.filter(title__icontains=query)
        
        else:
            object_list = self.model.objects.none()

        return object_list

class MovieYear(YearArchiveView):
    queryset = Video.objects.all()
    date_field = 'year_of_production'
    make_object_list = True
    allow_future = True

    #print(queryset)
        
