### Understanding CRUD


Create -- POST
Retrieve / List / Search -- GET
Update -- PUT / Patch / POST
Delete -- Delete
