from django.db import models
from django.utils import timezone
from django.utils import timezone
import datetime

import random
import os
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from django.db.models import Q
from django.db.models.signals import pre_save, post_save
from django.urls import reverse


from Photo.utils import unique_slug_generator, get_filename

def get_filename_ext(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_image_path(instance, filename):
    # print(instance)
    #print(filename)
    new_filename = random.randint(1,3910209312)
    name, ext = get_filename_ext(filename)
    final_filename = '{new_filename}{ext}'.format(new_filename=new_filename, ext=ext)
    return "photos/{new_filename}/{final_filename}".format(
            new_filename=new_filename, 
            final_filename=final_filename
            )


   

class Contact(models.Model):
    subject = models.CharField(max_length=50)
    from_email = models.EmailField()
    phone = models.CharField(max_length=9)
    message = models.TextField(verbose_name='Conteúdo')
    image           = models.ImageField(upload_to=upload_image_path, null=True, blank=True)
  
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp'] # most recent saved show up first
        verbose_name = 'Client contact'
        verbose_name_plural = 'Client contacts'


    def __str__(self):
        return self.subject

     