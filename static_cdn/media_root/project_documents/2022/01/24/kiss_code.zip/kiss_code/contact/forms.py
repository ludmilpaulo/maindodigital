from django import forms

from django import forms
from .models import Contact
from django.utils.translation import ugettext_lazy as _

import datetime
#from django.forms.extras.widgets import SelectDateWidget
from django.forms.widgets import SelectDateWidget
from django.forms import ModelForm, Form, DateInput
from django.contrib.admin import widgets
from django.contrib.admin.widgets import AdminDateWidget


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        
        fields = ['from_email', 'phone', 'subject', 'message']
        widgets = {
            'subject': forms.TextInput(attrs={'placeholder': 'Full Name'}),
            'from_email': forms.TextInput(attrs={'placeholder': 'Email'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Phone Number'}),
            'message': forms.Textarea(attrs={'placeholder': '\t\tMessage'}),
           
        }
        labels ={
            'subject': _(""),
            'from_email': _(""),
            'phone': _(""),
            'message': _(""),
           
        }


def email(self):
        email = self.cleaned_data.get("subject")
        return email

def name(self):
        name = self.cleaned_data.get("from_email")
        return name

def name(self):
        phone = self.cleaned_data.get("phone")
        return phone

def content(self):
        content = self.cleaned_data.get("message")
        return content
