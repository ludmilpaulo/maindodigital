from django.urls import path
from . import views 


app_name = 'BooKing'


urlpatterns = [
    path('',views.reserve_table , name='reserve_table' ),
]