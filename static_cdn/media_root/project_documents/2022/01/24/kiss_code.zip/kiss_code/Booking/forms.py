from django import forms
from .models import Reservation
from django.utils.translation import ugettext_lazy as _

import datetime
#from django.forms.extras.widgets import SelectDateWidget
from django.forms.widgets import SelectDateWidget
from django.forms import ModelForm, Form, DateInput
from django.contrib.admin import widgets
from django.contrib.admin.widgets import AdminDateWidget


class ReserveTableForm(forms.ModelForm):
    class Meta:
        model = Reservation
        
        fields = ['name', 'email', 'phone', 'content']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Name'}),
            'email': forms.TextInput(attrs={'placeholder': 'Email'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Phone Number'}),
            'content': forms.Textarea(attrs={'placeholder': 'Messagen'}),
            # 'time': DateInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
            # 'Date': DateInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M'),
        }
        labels ={
            'name': _(""),
            'email': _(""),
            'phone': _(""),
            'tipo_de_servico': _(""),
            'content': _(""),
            'time': _(""),
            'Date': _(""),
        }

        # content  = forms.CharField(label='',
        #     widget=forms.Textarea(
        #         attrs={
        #             'class': 'form-control',
        #             "placeholder": "messagem" 
        #             }
        #         )
        #     )


def email(self):
        email = self.cleaned_data.get("email")
        return email

def name(self):
        name = self.cleaned_data.get("name")
        return name

def content(self):
        content = self.cleaned_data.get("content")
        return content
