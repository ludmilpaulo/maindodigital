from django.apps import AppConfig


class VideoConfig(AppConfig):
    name = 'Video'
