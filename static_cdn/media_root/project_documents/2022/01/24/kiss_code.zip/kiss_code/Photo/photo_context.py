from .models import *


def slider_photo(request):
    movies = Picture.objects.all().order_by('created')[0:3]
    # movies = Movie.objects.last()
    return {'slider_movie' : movies}